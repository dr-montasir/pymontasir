## My first python package

### Installation
```shell
pip install pymontasir
```

### Usage
```python
from pymontasir import say_hello

# Generate "Hello, World!"
say_hello()

# Generate "Hello, Everybody!"
say_hello("Everybody")
```
